<?php
include("db.php");
if(isset($_GET["ManagerId"])){
    $id = $_GET["ManagerId"];
}
$sql = $conn->query("DELETE FROM Manager WHERE ManagerId = '$id'");
if($sql){
    header("location:../admins.php");
}
else{
    echo "error";
}
?>