<?php
session_start();
include("./config/db.php");
if(isset($_POST["Log"])){
  $managername = $_POST["ManagerName"];
  $_SESSION["ManagerName"] = $managername;
  $managerpassword = $_POST["ManagerPassword"];

  if(empty($managername) || empty($managerpassword)){
    echo "<script>alert('please enter full details')</script>";
  }
  else{
   $select = $conn->query("SELECT * FROM manager WHERE ManagerName = '$managername' AND ManagerPassword = '$managerpassword'");
   if(mysqli_num_rows($select) == 1){
    $_SESSION["ManagerName"] = $managername;
    header("location:index.php");
   }
   else{
    echo "<script>alert('user not found')</script>";
   }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <style>
      .back{
        width: 500px;
        height: 500px;
        background-color: rgb(220, 218, 223);
        border-radius: 5px;
        margin-left: 420px;
        margin-top: 70px;
      }
      .form{
        margin-left: 450px;
        margin-top: -460px;
      }
      .form h1{
        margin-left: 75px;
        color: blue;
      }
      .form .manager_name label{
        font-size: 25px;
        font-family: serif;
        color: blue;
      }
      .form .manager_name input{
        width: 430px;
        height: 50px;
        margin-top: 10px;
        border:  1px solid grey;
        color: blue;
      }
      .form .manager_password label{
        font-size: 25px;
        font-family: serif;
        color: blue;
      }
      .form .manager_password input{
        width: 430px;
        height: 50px;
        margin-top: 10px;
        border:  1px solid grey;
        color: blue;
      }
    .form .manager_password input:focus{
      outline: none;
      }
      .form .manager_name input:focus{
      outline: none;
      }
      .form .manager_name input:focus + .go_one{
        animation-name: animate;
        animation-duration: 0.3s;
        animation-fill-mode: forwards;
      }
      .form .manager_password input:focus + .go_two{
        animation-name: animatee;
        animation-duration: 0.3s;
        animation-fill-mode: forwards;
      }
      .but{
        margin-top: 20px;
      }
      .but button{
        width: 200px;
        height: 50px;
        border-radius: 5px;
        background-color: blue;
        border: transparent;
        color: white;
        cursor: pointer;
      }
      .but button:hover{
        background-color: rgb(53, 53, 235);
        transition: 1s;
        box-shadow: 1px 10px 20px 1px hsl(200, 90%, 50%);
      }
      .manager_name{
        margin-top: 20px;
      }
      .manager_password{
        margin-top: 20px;
      }
      .go_one{
        height: 2px;
        width: 436.2px;
      }
      .go_two{
        height: 2px;
        width: 436.2px;
      }
      @keyframes animate{
        from{
        width: 0px;
        height: 2px;
        background-color: blue;
        }
        to{
        height: 2px;
        width: 436.2px;
        background-color: blue;
        }
      }
      @keyframes animatee{
        from{
        width: 0px;
        height: 2px;
        background-color: blue;
        }
        to{
        height: 2px;
        width: 436.2px;
        background-color: blue;
        }
      }
      @media screen and (max-width: 768px) {
            .container{
              margin-left: -430px;
              margin-top: -60px;
              
            }
            h1{
              font-size: 15px;
            }
            .back{
              width: 65%;
              height: 900px;
            }
            .form{
              margin-top: -850px;
            }
            h1{
              font-size: 50px;
            }
           #ManagerName{
            width: 96%;
            height: 2.5cm;
            font-size: 35px;
           }
           #ManagerPassword{
            width: 96%;
            height: 2.5cm;
            font-size: 35px;
           }
           #ManagerNameLabel{
            font-size: 40px;
           }
           #ManagerPasswordLabel{
            font-size: 40px;
           }
           #h1{
            margin-left: 160px; 
          }
           #butt{
            width: 320px;
            height: 90px;
            font-size: 35px;
           }
           #name{
            margin-top: 40px;
           }
           #pass{
            margin-top: 40px;
           }
           #butto{
            margin-top: 40px;
           }
           #all{
            margin-top: 100px;
           }
        }
  
    </style>
</head>
<body>
  <div class="container">
    <div class="back"></div>
    <div class="form">
      <div id="all">
        <form action="" method="post">
          <div id="h11">
            <h1 id="h1">Log to you account</h1>
            </div>
            <div class="manager_name" id="name">
                <label for="" id="ManagerNameLabel">Manager Name</label><br>
                <input type="text" name="ManagerName" placeholder="Manager Name" id="ManagerName">
                <div class="go_one"></div>
            </div>
            <div class="manager_password" id="pass">
                <label for="" id="ManagerPasswordLabel">Manager Password</label><br>
                <input type="password" name="ManagerPassword" placeholder="Manager Password" id="ManagerPassword">
                <div class="go_two"></div>
            </div>
            <div class="but" id="butto">
                <button type="submit" name="Log" id="butt">Login</button>
            </div>
        </form>
      </div>
    </div>
    </div>
</body>

</html>
