<?php
session_start();
include("./config/db.php");
if(!isset($_SESSION["ManagerName"])){
    header("location:ManagerLogin.php");
}
if(isset($_POST["export"])){
    $id = $_POST["FurnitureId"];
    $quantity = $_POST["Quantity"];

    if(empty($id) || empty($quantity)){
        echo "<script>alert('Please enter all details.')</script>";
    }
    else{
        $sql = $conn->query("SELECT SUM(ImportQuantity) AS TotalImported FROM import WHERE FurnitureId = '$id'");
        $row = $sql->fetch_assoc();
        $totalImported = $row["TotalImported"];
        
        $sql = $conn->query("SELECT COALESCE(SUM(ExportQuantity),0) AS TotalExported FROM export WHERE FurnitureId = '$id'");
        $row = $sql->fetch_assoc();
        $totalExported = $row["TotalExported"];
        
        $remainingQuantity = $totalImported - $totalExported;
        
        if($quantity > $remainingQuantity){
            echo "<script>alert('Error: Insufficient Quantity.')</script>";
        }
        else{
            $checkExistQuery = $conn->query("SELECT * FROM export WHERE FurnitureId = '$id'");
            
            if($checkExistQuery->num_rows > 0){
                $updateQuery = $conn->query("UPDATE export SET ExportQuantity = ExportQuantity + $quantity WHERE FurnitureId = '$id'");
                if($updateQuery){
                    echo "<script>alert('Export quantity updated successfully.')</script>";
                    header("location:EportedProduct.php");
                }
                else{
                    echo "<script>alert('Error updating export quantity.')</script>";
                }
            }
            else{
                $insertQuery = $conn->query("INSERT INTO export (FurnitureId, ExportQuantity) VALUES ('$id','$quantity')");
                if($insertQuery){
                    echo "<script>alert('Product exported successfully.')</script>";
                    header("location:EportedProduct.php");
                }
                else{
                    echo "<script>alert('Error exporting product.')</script>";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, materialpro admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, materialpro admin lite design, materialpro admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description"
        content="Material Pro Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>Cargo Ltd</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/materialpro-lite/" />
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <link href="../assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="../assets/plugins/chartist-js/dist/chartist-init.css" rel="stylesheet">
    <link href="../assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <link href="../assets/plugins/c3-master/c3.min.css" rel="stylesheet">
    <link href="css/style.min.css" rel="stylesheet">
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin6">
                    <a class="navbar-brand ms-4" href="index.php">
                        <span class="logo-text" style="font-weight: bold; color: white; font-size: 30px;">
                          CARGO LTD
                        </span>
                    </a>

                    <a class="nav-toggler waves-effect waves-light text-white d-block d-md-none"
                        href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                </div>
                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav d-lg-none d-md-block ">
                        <li class="nav-item">
                            <a class="nav-toggler nav-link waves-effect waves-light text-white "
                                href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                        </li>
                    </ul>
                    <ul class="navbar-nav me-auto mt-md-0 ">

                       
                    </ul>

                    <?php
                    $value = $_SESSION["ManagerName"];
                    $choose = $conn->query("SELECT * FROM manager WHERE ManagerName = '$value'");
                    while($row = mysqli_fetch_assoc($choose)):
                    ?>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="#"
                                id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img width="45px" height="45px" style="border-radius: 100%; margin-top: -5px;" src="data:image/jpeg;base64,<?php echo base64_encode($row['ManagerImage']); ?>"><span style="margin-left: 10px;"><?php echo $row["ManagerName"]; ?></span>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown"></ul>
                        </li>
                    </ul>
                    <?php endwhile; ?>
                </div>
            </nav>
        </header>
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <div class="scroll-sidebar">
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="index.php" aria-expanded="false"><i class="mdi me-2 mdi-gauge"></i><span
                                    class="hide-menu">Dashboard</span></a></li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="products.php" aria-expanded="false"><i class="mdi me-2 mdi-table"></i><span
                                    class="hide-menu">Manage Product</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="admins.php" aria-expanded="false"><i class="mdi me-2 mdi-account"></i><span
                                    class="hide-menu">Admins</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="ImportedProduct.php" aria-expanded="false"><i
                                    class="mdi me-2 mdi-airplane"></i><span class="hide-menu">Imported
                                    Products</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="EportedProduct.php" aria-expanded="false"><i class="mdi me-2 mdi-truck"></i><span
                                    class="hide-menu">Exported Product</span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="report.php" aria-expanded="false"><i class="mdi me-2 mdi-book"></i><span
                                    class="hide-menu">Report</span></a>
                        </li>
                       
                    </ul>

                </nav>
            </div>
            <div class="sidebar-footer">
                <div class="row">
                    <div class="col-4 link-wrap">
                        <a href="setting.php" class="link" data-toggle="tooltip" title=""
                            data-original-title="Settings"><i class="ti-settings"></i></a>
                    </div>
                    
                    <div class="col-4 link-wrap" style="margin-left: 80px;">
                        <a href="./config/logout.php" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i
                                class="mdi mdi-power"></i></a>
                    </div>
                </div>
            </div>
        </aside>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="page-title mb-0 p-0">Dashboard</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-6 col-4 align-self-center">
                    </div>
                </div>
            </div>
            <div class="container-fluid">
            <style>
      .back{
        width: 500px;
        height: 580px;
        background-color: rgb(220, 218, 223);
        border-radius: 5px;
        margin-left: 420px;
        margin-top: 70px;
      }
      .form{
        margin-left: 450px;
        margin-top: -530px;
      }
      .form h1{
        margin-left: 75px;
        color: blue;
      }
      .form .manager_name label{
        font-size: 25px;
        font-family: serif;
        color: blue;
      }
      .form .manager_name input{
        width: 430px;
        height: 50px;
        margin-top: 10px;
        border:  1px solid grey;
        color: blue;
      }
      .form .manager_Id label{
        font-size: 25px;
        font-family: serif;
        color: blue;
      }
      .form .manager_Id input{
        width: 430px;
        height: 50px;
        margin-top: 10px;
        border:  1px solid grey;
        color: blue;
      }
      .form .manager_password label{
        font-size: 25px;
        font-family: serif;
        color: blue;
      }
      .form .manager_password input{
        width: 430px;
        height: 50px;
        margin-top: 10px;
        border:  1px solid grey;
        color: blue;
      }
      .form .manager_Id input:focus + .go_one{
        animation-name: animate;
        animation-duration: 0.3s;
        animation-fill-mode: forwards;
      }
    .form .manager_password input:focus{
      outline: none;
      }
      .form .manager_name input:focus{
      outline: none;
      }
      .form .manager_name input:focus + .go_one{
        animation-name: animate;
        animation-duration: 0.3s;
        animation-fill-mode: forwards;
      }
      .form .manager_password input:focus + .go_two{
        animation-name: animatee;
        animation-duration: 0.3s;
        animation-fill-mode: forwards;
      }
      .but{
        margin-top: 20px;
      }
      .but button{
        width: 200px;
        height: 50px;
        border-radius: 5px;
        background-color: blue;
        border: transparent;
        color: white;
        cursor: pointer;
      }
      .but button:hover{
        background-color: rgb(53, 53, 235);
        transition: 1s;
        box-shadow: 1px 10px 20px 1px hsl(200, 90%, 50%);
      }
      .manager_name{
        margin-top: 20px;
      }
      .manager_password{
        margin-top: 20px;
      }
      .go_one{
        height: 2px;
        width: 436.2px;
      }
      .go_two{
        height: 2px;
        width: 436.2px;
      }
      .container{
        margin-left: -200px;
        margin-top: -30px;
      }
      @keyframes animate{
        from{
        width: 0px;
        height: 2px;
        background-color: blue;
        }
        to{
        height: 2px;
        width: 430px;
        background-color: blue;
        }
      }
      @keyframes animatee{
        from{
        width: 0px;
        height: 2px;
        background-color: blue;
        }
        to{
        height: 2px;
        width: 430px;
        background-color: blue;
        }
        
      }
    </style>
</head>
<body>
    <div class="container">
    <div class="back"></div>
    <div class="form">
        <form action="" method="post"  enctype="multipart/form-data">
            <div class="manager_Id">
                <label for="">FurnitureId</label><br>
                <input type="text" name="FurnitureId" placeholder="FurnitureId">
                <div class="go_one"></div>
            </div>
            <div class="manager_password">
                <label for="">Quantity</label><br>
                <input type="number" name="Quantity" placeholder="Furniture Quantity" >
                <div class="go_two"></div>
            </div>
            <div class="but">
                <button type="submit" name="export">Export Product</button>
            </div>
        </form>
    </div>
    </div>
</body>
    </div>
    </div>

    <script src="../assets/plugins/jquery/dist/jquery.min.js"></script>
    <script src="../assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="../assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="../assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../assets/plugins/d3/d3.min.js"></script>
    <script src="../assets/plugins/c3-master/c3.min.js"></script>
    <script src="js/pages/dashboards/dashboard1.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>