<?php
include("./config/db.php");
session_start();
if(!isset($_SESSION["ManagerName"])){
    header("location:ManagerLogin.php");
}
?>
<?php
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, materialpro admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, materialpro admin lite design, materialpro admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description"
        content="Material Pro Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>Material Pro Lite Template by WrapPixel</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/materialpro-lite/" />

    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">

    <link href="css/style.min.css" rel="stylesheet">

</head>

<body>

    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">

        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin6">

                    <a class="navbar-brand ms-4" href="index.php">
                        <span class="logo-text" style="font-weight: bold; color: white; font-size: 30px;">
                          CARGO LTD
                        </span>
                    </a>

                    <a class="nav-toggler waves-effect waves-light text-white d-block d-md-none"
                        href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                </div>

                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav d-lg-none d-md-block ">
                        <li class="nav-item">
                            <a class="nav-toggler nav-link waves-effect waves-light text-white "
                                href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                        </li>
                    </ul>

                    <ul class="navbar-nav me-auto mt-md-0 ">


                        
                    </ul>
                    <?php
                    $value = $_SESSION["ManagerName"];
                    $choose = $conn->query("SELECT * FROM manager WHERE ManagerName = '$value'");
                    while($row = mysqli_fetch_assoc($choose)):
                    ?>
                     <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="#"
                                id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img width="45px" height="45px" style="border-radius: 100%; margin-top: -5px;" src="data:image/jpeg;base64,<?php echo base64_encode($row['ManagerImage']); ?>"><span style="margin-left: 10px;"><?php echo $row["ManagerName"]; ?></span>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown"></ul>
                        </li>
                    </ul>
                    <?php endwhile; ?>
                </div>
            </nav>
        </header>

        <aside class="left-sidebar" data-sidebarbg="skin6">

            <div class="scroll-sidebar">

                <nav class="sidebar-nav">
                    <ul id="sidebarnav">

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="index.php" aria-expanded="false"><i class="mdi me-2 mdi-gauge"></i><span
                                    class="hide-menu">Dashboard</span></a></li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="products.php" aria-expanded="false"><i class="mdi me-2 mdi-table"></i><span
                                    class="hide-menu">Manage Product</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="admins.php" aria-expanded="false"><i class="mdi me-2 mdi-account"></i><span
                                    class="hide-menu">Admins</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="ImportedProduct.php" aria-expanded="false"><i
                                    class="mdi me-2 mdi-airplane"></i><span class="hide-menu">Imported
                                    Products</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="EportedProduct.php" aria-expanded="false"><i class="mdi me-2 mdi-truck"></i><span
                                    class="hide-menu">Exported Product</span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="report.php" aria-expanded="false"><i class="mdi me-2 mdi-book"></i><span
                                    class="hide-menu">Report</span></a>
                        </li>

                      

                    </ul>

                </nav>

            </div>

            <div class="sidebar-footer">
                <div class="row">
                    <div class="col-4 link-wrap">

                        <a href="setting.php" class="link" data-toggle="tooltip" title=""
                            data-original-title="Settings"><i class="ti-settings"></i></a>
                    </div>
                    
                    <div class="col-4 link-wrap" style="margin-left: 80px;">

                        <a href="./config/logout.php" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i
                                class="mdi mdi-power"></i></a>
                    </div>
                </div>
            </div>
        </aside>

        <div class="page-wrapper">

            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="page-title mb-0 p-0">Report</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Report</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-6 col-4 align-self-center">

                    </div>
                </div>
            </div>

            <div class="container-fluid">
            <style>
                label{
                    font-size: 25px;
                }
                input{
                    width: 500px;
                    height: 50px;
                    border-radius: 5px;
                    border: 1px solid;
                }
                button{
                    margin-top: 10px;
                    width: 150px;
                    height: 40px;
                    border-radius: 5px;
                    border: 1px solid;
                }
                @media screen and (max-width: 768px) {
                    input{
                        width: 328px;
                    }
                }
            </style>
                <div class="row">
                    <form action="" method="post" class="noPrint">
                    <div class="col-12">
                    <div class="from">
                    <label for="" id="from_label">From</label><br>
                    <input type="date" name="from">
                    </div>
                    <div class="to">
                    <label for="" id="to_label">To</label><br>
                    <input type="date" name="to">
                    </div>
                    <div class="button">
                        <button type="submit" name="reports">Get Report</button>
                    </div>
                    </form>
                    </div>
                </div><br>
                <div class="row">
<div class="col-sm-12" style="margin-top: 20px;">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">My Report</h4>
            <div class="table-responsive">
                <table class="table general-table" id="print">
                    <thead>
                        <tr>
                            <th class="border-top-0">#</th>
                            <th class="border-top-0">FurnitureImage</th>
                            <th class="border-top-0">FurnitureName</th>
                            <th class="border-top-0">FurnitureOwnerName</th>
                            <th class="border-top-0">ImportedDate</th>
                            <th class="border-top-0">ImportedQuantity</th>
                            <th class="border-top-0">ExportedDate</th>
                            <th class="border-top-0">ExportedQuantity</th>
                            <th class="border-top-0">RemainedQuantity</th>
                        </tr>
                    </thead>
                    <?php 
                    if(isset($_POST["reports"])){
                        $from = $_POST["from"];

                        $to = $_POST["to"];
                    if(empty($from) || empty($to)){
                    echo "<script>alert('please we are unable to give you data you want couse we dont what to base on')</script>";
                    }
                    else{
        $sel = $conn->query("SELECT import.FurnitureId, 
       import.FurnitureImages, 
       import.ImportDate, 
       import.ImportQuantity, 
       export.FurnitureId AS ExportedFurnitureId, 
       export.ExportDate, 
       export.ExportQuantity, 
       furniture.FurnitureId AS FurnitureId,
       furniture.FurnitureName, 
       furniture.FurnitureOwnerName,
       import.ImportQuantity - COALESCE(SUM(export.ExportQuantity),0) AS RemainingQuantity 
       FROM import
       JOIN furniture ON import.FurnitureId = furniture.FurnitureId
       LEFT JOIN export ON import.FurnitureId = export.FurnitureId WHERE import.ImportDate >= '$from' AND export.ExportDate <= '$to'
        GROUP BY import.FurnitureId, 
        import.FurnitureImages, 
        import.ImportDate, 
        import.ImportQuantity,
        ExportedFurnitureId,
        export.ExportDate, 
        export.ExportQuantity,
        furniture.FurnitureId, 
        furniture.FurnitureName, 
        furniture.FurnitureOwnerName;");
        while($row = mysqli_fetch_assoc($sel)){
            echo "
            <tbody>
            <tr>
            <td>$row[FurnitureId]</td>
            <td><img width='70px' height='70px' src='data:image/jpeg;base64,".base64_encode($row['FurnitureImages'])."'></td>
            </td>
            <td>$row[FurnitureName]</td>
            <td>$row[FurnitureOwnerName] </td>
            <td>$row[ImportDate]</td>
            <td>$row[ImportQuantity]</td>
            <td>$row[ExportDate]</td>
            <td>$row[ExportQuantity]</td>
            <td>$row[RemainingQuantity]</td>
            </tr>
        </tbody>
            ";
                        }
                    }
                }
                    ?>
                </table>
            </div>
        </div>
    </div>
     <div class="bt" style="margin-top: -30px;">
                    <button type="submit" onclick="display()" id="prints">Print</button>
                </div>
              </div>
            </div>

        </div>

    </div>
    <div class="container-fluid">
                </div>

            </div>

    <script src="../assets/plugins/jquery/dist/jquery.min.js"></script>

    <script src="../assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>

    <script src="js/waves.js"></script>

    <script src="js/sidebarmenu.js"></script>

    <script src="js/custom.js"></script>
</body>
<script>
function display(){
    var hide = document.querySelector('.noPrint');
    for(var i = 0; i<hide.length;i++){
        hide[i].style.display='none';
        document.getElementById("from_label").style.display="none";
        document.getElementById("to_label").style.display="none";
        document.getElementById("prints").style.display="none";
    }
    window.print();

    for(var i = 0; i<hide.length;i++){
        hide[i].style.display='block';
        document.getElementById("from_label").style.display="block";
        document.getElementById("to_label").style.display="block";
        document.getElementById("prints").style.display="block";
    }
}
</script>
</html>