<?php
include("./config/db.php");
session_start();
if(!isset($_SESSION["ManagerName"])){
    header("location:ManagerLogin.php");
}
?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
        content="wrappixel, admin dashboard, html css dashboard, web dashboard, bootstrap 5 admin, bootstrap 5, css3 dashboard, bootstrap 5 dashboard, materialpro admin bootstrap 5 dashboard, frontend, responsive bootstrap 5 admin template, materialpro admin lite design, materialpro admin lite dashboard bootstrap 5 dashboard template">
    <meta name="description"
        content="Material Pro Lite is powerful and clean admin dashboard template, inpired from Bootstrap Framework">
    <meta name="robots" content="noindex,nofollow">
    <title>Material Pro Lite Template by WrapPixel</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/materialpro-lite/" />
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <link href="css/style.min.css" rel="stylesheet">
</head>

<body>
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
        data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
        <header class="topbar" data-navbarbg="skin6">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header" data-logobg="skin6">
                    <a class="navbar-brand ms-4" href="index.php">
                        <span class="logo-text" style="font-weight: bold; color: white; font-size: 30px;">
                          CARGO LTD
                        </span>
                    </a>

                    <a class="nav-toggler waves-effect waves-light text-white d-block d-md-none"
                        href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                </div>

                <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                    <ul class="navbar-nav d-lg-none d-md-block ">
                        <li class="nav-item">
                            <a class="nav-toggler nav-link waves-effect waves-light text-white "
                                href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                        </li>
                    </ul>

                    <ul class="navbar-nav me-auto mt-md-0 ">


                        
                    </ul>


                    <?php
                    $value = $_SESSION["ManagerName"];
                    $choose = $conn->query("SELECT * FROM manager WHERE ManagerName = '$value'");
                    while($row = mysqli_fetch_assoc($choose)):
                    ?>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="#"
                                id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img width="45px" height="45px" style="border-radius: 100%; margin-top: -5px;" src="data:image/jpeg;base64,<?php echo base64_encode($row['ManagerImage']); ?>"><span style="margin-left: 10px;"><?php echo $row["ManagerName"]; ?></span>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown"></ul>
                        </li>
                    </ul>
                    <?php endwhile; ?>
                </div>
            </nav>
        </header>

        <aside class="left-sidebar" data-sidebarbg="skin6">

            <div class="scroll-sidebar">

                <nav class="sidebar-nav">
                    <ul id="sidebarnav">

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="index.php" aria-expanded="false"><i class="mdi me-2 mdi-gauge"></i><span
                                    class="hide-menu">Dashboard</span></a></li>

                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="products.php" aria-expanded="false"><i class="mdi me-2 mdi-table"></i><span
                                    class="hide-menu">Manage Product</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="admins.php" aria-expanded="false"><i class="mdi me-2 mdi-account"></i><span
                                    class="hide-menu">Admins</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="ImportedProduct.php" aria-expanded="false"><i
                                    class="mdi me-2 mdi-airplane"></i><span class="hide-menu">Imported
                                    Products</span></a></li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="EportedProduct.php" aria-expanded="false"><i class="mdi me-2 mdi-truck"></i><span
                                    class="hide-menu">Exported Product</span></a>
                        </li>
                        <li class="sidebar-item"> <a class="sidebar-link waves-effect waves-dark sidebar-link"
                                href="report.php" aria-expanded="false"><i class="mdi me-2 mdi-book"></i><span
                                    class="hide-menu">Report</span></a>
                        </li>
                        

                    </ul>

                </nav>

            </div>

            <div class="sidebar-footer">
                <div class="row">
                    <div class="col-4 link-wrap">

                        <a href="setting.php" class="link" data-toggle="tooltip" title=""
                            data-original-title="Settings"><i class="ti-settings"></i></a>
                    </div>
                   
                    <div class="col-4 link-wrap" style="margin-left: 80px;">
                        <a href="./config/logout.php" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i
                                class="mdi mdi-power"></i></a>
                    </div>
                </div>
            </div>
        </aside>

        <div class="page-wrapper">

            <div class="page-breadcrumb">
                <div class="row align-items-center">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="page-title mb-0 p-0">Imported Product</h3>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Imported</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div class="col-md-6 col-4 align-self-center">
                    <div class="text-end upgrade-btn">
                            <a href="ImportProduct.php" class="btn btn-danger d-none d-md-inline-block text-white" target="_blank">Import
                                Product</a>
                        </div>
                        <div style="margin-left: 200px; margin-top: -35px;">
                            <a href="ExportProduct.php" class="btn btn-success d-none d-md-inline-block text-white" target="_blank">Export Some
                                Product</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
            <div class="row">

<div class="col-sm-12">
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">All Imported Products</h4>
            <div class="table-responsive">
                <table class="table user-table">
                    <thead>
                        <tr>
                            <th class="border-top-0">#</th>
                            <th class="border-top-0">FurnitureImage</th>
                            <th class="border-top-0">FurnitureName</th>
                            <th class="border-top-0">FurnitureOwnerName</th>
                            <th class="border-top-0">ImportDate</th>
                            <th class="border-top-0">quantity</th>
                        </tr>
                    </thead>
                    <?php
                     $sel = $conn->query("SELECT import.FurnitureId,import.FurnitureImages,import.ImportDate,import.ImportQuantity,furniture.FurnitureId,furniture.FurnitureName,furniture.FurnitureOwnerName FROM import JOIN furniture ON import.FurnitureId = furniture.FurnitureId");
                     while($row = mysqli_fetch_assoc($sel)):
                    ?>
                    <tbody>
                    <tr>
                        <td><?php echo $row["FurnitureId"]?></td>
                        <td><img width="70px" height="70px" src="data:image/jpeg;base64,<?php echo base64_encode($row['FurnitureImages']); ?>"></td>
                        <td><?php echo $row["FurnitureName"]?></td>
                        <td><?php echo $row["FurnitureOwnerName"]?></td>
                        <td><?php echo $row["ImportDate"]?></td>
                        <td><?php echo $row["ImportQuantity"]?></td>
                    </tr>
                    </tbody>
                    <?php endwhile; ?>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
        </div>
    </div>
    <script src="../assets/plugins/jquery/dist/jquery.min.js"></script>
    <script src="../assets/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/app-style-switcher.js"></script>
    <script src="js/waves.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script src="../assets/plugins/gmaps/gmaps.min.js"></script>
    <script src="../assets/plugins/gmaps/jquery.gmaps.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>